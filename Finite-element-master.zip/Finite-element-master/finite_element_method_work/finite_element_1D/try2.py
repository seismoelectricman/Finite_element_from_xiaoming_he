import numpy as np
import cv2
from scipy import sparse
import matplotlib.pyplot as plt
import time

help()
